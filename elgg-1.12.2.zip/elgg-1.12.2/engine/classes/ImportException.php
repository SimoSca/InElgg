<?php
/**
 * Import exception
 *
 * @package    Elgg.Core
 * @subpackage Exception
 * @deprecated 1.9
 */
class ImportException extends \DataFormatException {}
