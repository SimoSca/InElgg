<?php
/**
 * InvalidParameterException
 * A parameter is invalid.
 *
 * @package    Elgg.Core
 * @subpackage Exception
 */
class InvalidParameterException extends \CallException {}
