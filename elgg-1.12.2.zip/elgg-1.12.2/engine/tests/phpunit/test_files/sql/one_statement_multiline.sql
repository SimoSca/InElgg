INSERT INTO prefix_sometable (`key`)
VALUES ('Value');
