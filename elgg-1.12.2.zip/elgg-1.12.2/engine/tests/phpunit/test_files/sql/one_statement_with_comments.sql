-- This is the first comment
INSERT INTO prefix_sometable (`key`) VALUES ('Value -- not a comment');
-- This is another comment
