<?php

interface I1_20130207 {

}

class C1_20130207 {

}
