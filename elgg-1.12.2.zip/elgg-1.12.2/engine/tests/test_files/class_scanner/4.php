<?php
namespace NS4_20130207;


interface I4_20130207 {

}

class C4_20130207 {

}

trait T4_20130207 {

}

